public class Demo{
    public static void main(String[] args){
      
      Student s=new Student();
      s.display("name","email",cgpa);
      s.setstudent("name","email",cgpa);
      s.getstudent("name","email",cgpa);

}

