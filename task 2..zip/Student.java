//NAME:Muhammad Usama
//Reg no:sp25-bcs-151

public class Student{
   String name="usama";
   String email="muhammadus9129@gmail.com";
   double cgpa="4";

  public void display(String name,String email,double cgpa){
        System.out.println("Name="+s.name+",Email"+email+",cgpa="+cgpa);
        
    Student(String name,String email,double cgpa){
        
     }
    public void setstudent(String name,String email,double cgpa){
       this.name=name;
        this.email=email;
        this.cgpa=cgpa
    }

    public void getstudent(String name,String email,double cgpa){
      this.name=name;
       return this.name;
      
}